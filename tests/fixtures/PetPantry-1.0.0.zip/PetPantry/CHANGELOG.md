# Pet Pantry

## 1.0.0 — first release
- Click your pet portrait (or press a keybind) to feed your pet.
- Food priority list: only foods you list are ever used, top of the list first. Drag food in or use "+ Add food from bags".
- Pet card: portrait, name, mood, loyalty, level, meal count, next meal and an animated XP bar.
- Hungry glow on the pet portrait.
- "Don't feed when Happy" option (with sassy jokes if you try anyway).
- Low food warning and vendor pet-food alert.
- Your pet talks: mood lines, idle chatter, combat lines (low health, death, healed), meal reactions — with species-specific noises and lines.
- Optional sharing of pet lines as an emote or in party/raid chat (off by default).
- Milestone titles at 10 / 50 / 100 / 250 / 500 / 1000 meals.
- Sounds: munch, whimper and milestone fanfare.
- Four themes: Forever, Obsidian, Teal, Crimson.
- Minimap button, movable speech bubble.
